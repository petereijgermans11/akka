akka-extensions

# Exercise 20 > Akka Extensions

In this exercise, we will create an Akka `extension` for configuration related
settings.

- Create an `extension` for all configuration settings related to `CoffeeHouse`:

    - Define the `Settings` singleton object and the `Settings` class.
    - Define the `SettingsActor` trait for convenient access inside our actors.
    - Provide `val` attributes for all settings underneath `coffee-house`.

- Replace all occurrences of direct setting access:

    - Outside of actors, use `Settings(system).something`.
    - Inside actors mix in the `SettingsActor` trait.

- Use the `run` command to boot the `CoffeeHouseApp` and verify everything works
  as expected.

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.
