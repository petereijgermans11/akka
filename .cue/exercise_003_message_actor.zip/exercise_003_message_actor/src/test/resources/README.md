message-actor

# Exercise 3 > Message Actor

In this exercise, we will send a message to our `CoffeeHouse`.

- In the `CoffeeHouseApp` constructor, send `CoffeeHouse` the `"Brew Coffee"` message.

- Use the `run` command to boot the `CoffeeHouseApp` and verify:

    - `"CoffeeHouse Open"` is logged to `coffee-house.log`.
    - `"Coffee Brewing"` is logged to `coffee-house.log`.

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.
