fsm

# Exercise 21 > Fsm

In this exercise, we will replace our `become` and `stash` logic with FSM.

- Re-factor `Barista`: Instead of the `become` based state matching, use `FSM`.

- Re-factor `Guest`: Introduce an `FSM` based state machine.

- Use the `run` command to boot the `CoffeeHouseApp` and verify everything works
  as expected.

- Use the `test` command to verify the solution works as expected.

## Congratulations! You are Finished!
